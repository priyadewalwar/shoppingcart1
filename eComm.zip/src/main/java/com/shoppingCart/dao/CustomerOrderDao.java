package com.shoppingCart.dao;

import com.shoppingCart.model.CustomerOrder;

public interface CustomerOrderDao {

    void addCustomerOrder(CustomerOrder customerOrder);
}
